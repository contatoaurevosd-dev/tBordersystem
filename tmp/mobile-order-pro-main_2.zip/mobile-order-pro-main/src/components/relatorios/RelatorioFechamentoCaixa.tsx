import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, FileText, DollarSign, TrendingUp, TrendingDown, Calendar, User, Download } from "lucide-react";
import { toast } from "sonner";
import { format, parseISO, startOfMonth, endOfMonth } from "date-fns";
import { ptBR } from "date-fns/locale";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface CaixaFechado {
  id: string;
  data: string;
  valor_abertura: number;
  valor_fechamento: number | null;
  status: string;
  observacoes_abertura: string | null;
  observacoes_fechamento: string | null;
  aberto_em: string;
  fechado_em: string | null;
  aberto_por: string | null;
  fechado_por: string | null;
  profiles_abertura?: { nome: string | null; email: string } | null;
  profiles_fechamento?: { nome: string | null; email: string } | null;
  transacoes?: Array<{
    id: string;
    tipo: "receita" | "despesa";
    valor: number;
    descricao: string | null;
    metodo_pagamento: string | null;
    created_at: string;
  }>;
}

const RelatorioFechamentoCaixa = () => {
  const [caixas, setCaixas] = useState<CaixaFechado[]>([]);
  const [loading, setLoading] = useState(false);
  const [showFilters, setShowFilters] = useState(true);
  const [expandedCaixa, setExpandedCaixa] = useState<string | null>(null);

  const [dataInicial, setDataInicial] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [dataFinal, setDataFinal] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));

  const gerarRelatorio = async () => {
    setLoading(true);
    try {
      // Buscar caixas fechados no período
      const { data: caixasData, error: caixasError } = await supabase
        .from("caixa_diario")
        .select("*")
        .eq("status", "fechado")
        .gte("data", dataInicial)
        .lte("data", dataFinal)
        .order("data", { ascending: false });

      if (caixasError) throw caixasError;

      // Para cada caixa, buscar as transações do dia e perfis
      const caixasComTransacoes = await Promise.all(
        (caixasData || []).map(async (caixa) => {
          const [transacoesRes, profileAberturaRes, profileFechamentoRes] = await Promise.all([
            supabase
              .from("transacoes")
              .select("id, tipo, valor, descricao, metodo_pagamento, created_at")
              .eq("data", caixa.data)
              .order("created_at", { ascending: true }),
            caixa.aberto_por 
              ? supabase.from("profiles").select("nome, email").eq("id", caixa.aberto_por).maybeSingle()
              : Promise.resolve({ data: null }),
            caixa.fechado_por 
              ? supabase.from("profiles").select("nome, email").eq("id", caixa.fechado_por).maybeSingle()
              : Promise.resolve({ data: null }),
          ]);

          return {
            ...caixa,
            transacoes: transacoesRes.data || [],
            profiles_abertura: profileAberturaRes.data,
            profiles_fechamento: profileFechamentoRes.data,
          };
        })
      );

      setCaixas(caixasComTransacoes as CaixaFechado[]);
      
      if (caixasComTransacoes.length === 0) {
        toast.info("Nenhum caixa fechado encontrado no período");
      }
    } catch (error: any) {
      toast.error("Erro ao gerar relatório: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const calcularTotais = (transacoes: CaixaFechado["transacoes"]) => {
    if (!transacoes) return { entradas: 0, saidas: 0 };
    
    const entradas = transacoes
      .filter((t) => t.tipo === "receita")
      .reduce((sum, t) => sum + parseFloat(t.valor.toString()), 0);
    
    const saidas = transacoes
      .filter((t) => t.tipo === "despesa")
      .reduce((sum, t) => sum + parseFloat(t.valor.toString()), 0);

    return { entradas, saidas };
  };

  const calcularTotaisGerais = () => {
    let totalAbertura = 0;
    let totalFechamento = 0;
    let totalEntradas = 0;
    let totalSaidas = 0;
    let totalDiferenca = 0;

    caixas.forEach((caixa) => {
      totalAbertura += parseFloat(caixa.valor_abertura.toString());
      totalFechamento += parseFloat(caixa.valor_fechamento?.toString() || "0");
      
      const { entradas, saidas } = calcularTotais(caixa.transacoes);
      totalEntradas += entradas;
      totalSaidas += saidas;

      const saldoEsperado = parseFloat(caixa.valor_abertura.toString()) + entradas - saidas;
      const diferenca = parseFloat(caixa.valor_fechamento?.toString() || "0") - saldoEsperado;
      totalDiferenca += diferenca;
    });

    return { totalAbertura, totalFechamento, totalEntradas, totalSaidas, totalDiferenca };
  };

  const exportarPDF = () => {
    const doc = new jsPDF();
    const totaisGerais = calcularTotaisGerais();

    // Título
    doc.setFontSize(18);
    doc.text("Relatório de Fechamento de Caixa", 14, 22);

    // Período
    doc.setFontSize(10);
    doc.text(
      `Período: ${format(parseISO(dataInicial), "dd/MM/yyyy")} a ${format(parseISO(dataFinal), "dd/MM/yyyy")}`,
      14,
      32
    );

    // Resumo Geral
    doc.setFontSize(12);
    doc.text("Resumo Geral", 14, 45);
    
    autoTable(doc, {
      startY: 50,
      head: [["Métrica", "Valor"]],
      body: [
        ["Total Caixas Fechados", caixas.length.toString()],
        ["Total Aberturas", `R$ ${totaisGerais.totalAbertura.toFixed(2)}`],
        ["Total Fechamentos", `R$ ${totaisGerais.totalFechamento.toFixed(2)}`],
        ["Total Entradas", `R$ ${totaisGerais.totalEntradas.toFixed(2)}`],
        ["Total Saídas", `R$ ${totaisGerais.totalSaidas.toFixed(2)}`],
        ["Diferença Total", `R$ ${totaisGerais.totalDiferenca.toFixed(2)}`],
      ],
      theme: "striped",
    });

    // Detalhamento por Caixa
    let currentY = (doc as any).lastAutoTable.finalY + 15;

    caixas.forEach((caixa, index) => {
      if (currentY > 250) {
        doc.addPage();
        currentY = 20;
      }

      const { entradas, saidas } = calcularTotais(caixa.transacoes);
      const saldoEsperado = parseFloat(caixa.valor_abertura.toString()) + entradas - saidas;
      const diferenca = parseFloat(caixa.valor_fechamento?.toString() || "0") - saldoEsperado;

      doc.setFontSize(11);
      doc.text(
        `Caixa ${format(parseISO(caixa.data), "dd/MM/yyyy")} - ${caixa.profiles_abertura?.nome || caixa.profiles_abertura?.email || "N/A"}`,
        14,
        currentY
      );

      autoTable(doc, {
        startY: currentY + 5,
        head: [["Hora", "Tipo", "Descrição", "Método", "Valor"]],
        body: (caixa.transacoes || []).map((t) => [
          format(parseISO(t.created_at), "HH:mm"),
          t.tipo === "receita" ? "Entrada" : "Saída",
          t.descricao || "-",
          t.metodo_pagamento || "-",
          `R$ ${parseFloat(t.valor.toString()).toFixed(2)}`,
        ]),
        foot: [
          ["", "", "", "Abertura:", `R$ ${parseFloat(caixa.valor_abertura.toString()).toFixed(2)}`],
          ["", "", "", "Fechamento:", `R$ ${parseFloat(caixa.valor_fechamento?.toString() || "0").toFixed(2)}`],
          ["", "", "", "Diferença:", `R$ ${diferenca.toFixed(2)}`],
        ],
        theme: "grid",
        styles: { fontSize: 8 },
      });

      currentY = (doc as any).lastAutoTable.finalY + 15;
    });

    doc.save(`fechamento-caixa-${dataInicial}-${dataFinal}.pdf`);
    toast.success("PDF exportado com sucesso!");
  };

  const totaisGerais = calcularTotaisGerais();

  return (
    <div className="space-y-6">
      {/* Filtros */}
      <Collapsible open={showFilters} onOpenChange={setShowFilters}>
        <Card>
          <CardHeader className="pb-3">
            <CollapsibleTrigger className="flex items-center justify-between w-full">
              <CardTitle className="text-lg flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Filtros do Relatório
              </CardTitle>
              {showFilters ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
            </CollapsibleTrigger>
          </CardHeader>
          <CollapsibleContent>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Data Inicial</Label>
                  <Input
                    type="date"
                    value={dataInicial}
                    onChange={(e) => setDataInicial(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Data Final</Label>
                  <Input
                    type="date"
                    value={dataFinal}
                    onChange={(e) => setDataFinal(e.target.value)}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={gerarRelatorio} disabled={loading} className="w-full">
                    <FileText className="h-4 w-4 mr-2" />
                    {loading ? "Gerando..." : "Gerar Relatório"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      {/* Resumo Geral */}
      {caixas.length > 0 && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Caixas Fechados</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{caixas.length}</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  Total Entradas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-green-600">
                  R$ {totaisGerais.totalEntradas.toFixed(2)}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-red-500/10 to-red-600/5 border-red-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <TrendingDown className="h-4 w-4 text-red-600" />
                  Total Saídas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-red-600">
                  R$ {totaisGerais.totalSaidas.toFixed(2)}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <DollarSign className="h-4 w-4 text-blue-600" />
                  Total Fechamentos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-blue-600">
                  R$ {totaisGerais.totalFechamento.toFixed(2)}
                </p>
              </CardContent>
            </Card>

            <Card className={totaisGerais.totalDiferenca >= 0 ? "bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 border-emerald-200" : "bg-gradient-to-br from-orange-500/10 to-orange-600/5 border-orange-200"}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Diferença Total</CardTitle>
              </CardHeader>
              <CardContent>
                <p className={`text-2xl font-bold ${totaisGerais.totalDiferenca >= 0 ? "text-emerald-600" : "text-orange-600"}`}>
                  {totaisGerais.totalDiferenca >= 0 ? "+" : ""}R$ {totaisGerais.totalDiferenca.toFixed(2)}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Botão Exportar PDF */}
          <div className="flex justify-end">
            <Button variant="outline" onClick={exportarPDF}>
              <Download className="h-4 w-4 mr-2" />
              Exportar PDF
            </Button>
          </div>

          {/* Lista de Caixas Fechados */}
          <div className="space-y-4">
            {caixas.map((caixa) => {
              const { entradas, saidas } = calcularTotais(caixa.transacoes);
              const saldoEsperado = parseFloat(caixa.valor_abertura.toString()) + entradas - saidas;
              const diferenca = parseFloat(caixa.valor_fechamento?.toString() || "0") - saldoEsperado;
              const isExpanded = expandedCaixa === caixa.id;

              return (
                <Card key={caixa.id}>
                  <CardHeader 
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => setExpandedCaixa(isExpanded ? null : caixa.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div>
                          <CardTitle className="text-lg flex items-center gap-2">
                            <Calendar className="h-5 w-5" />
                            {format(parseISO(caixa.data), "dd/MM/yyyy", { locale: ptBR })}
                          </CardTitle>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <User className="h-4 w-4" />
                            {caixa.profiles_abertura?.nome || caixa.profiles_abertura?.email || "N/A"}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Fechamento</p>
                          <p className="text-lg font-bold">
                            R$ {parseFloat(caixa.valor_fechamento?.toString() || "0").toFixed(2)}
                          </p>
                        </div>
                        <Badge 
                          variant={Math.abs(diferenca) < 0.01 ? "default" : "destructive"}
                          className={Math.abs(diferenca) < 0.01 ? "bg-green-500" : ""}
                        >
                          {diferenca >= 0 ? "+" : ""}R$ {diferenca.toFixed(2)}
                        </Badge>
                        {isExpanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                      </div>
                    </div>
                  </CardHeader>

                  {isExpanded && (
                    <CardContent className="border-t">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 pt-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Abertura</p>
                          <p className="font-medium">R$ {parseFloat(caixa.valor_abertura.toString()).toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Entradas</p>
                          <p className="font-medium text-green-600">R$ {entradas.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Saídas</p>
                          <p className="font-medium text-red-600">R$ {saidas.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Saldo Esperado</p>
                          <p className="font-medium">R$ {saldoEsperado.toFixed(2)}</p>
                        </div>
                      </div>

                      {caixa.observacoes_fechamento && (
                        <div className="mb-4 p-3 bg-muted rounded-lg">
                          <p className="text-sm font-medium">Observações de Fechamento:</p>
                          <p className="text-sm text-muted-foreground">{caixa.observacoes_fechamento}</p>
                        </div>
                      )}

                      {caixa.transacoes && caixa.transacoes.length > 0 && (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Hora</TableHead>
                              <TableHead>Tipo</TableHead>
                              <TableHead>Descrição</TableHead>
                              <TableHead>Método</TableHead>
                              <TableHead className="text-right">Valor</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {caixa.transacoes.map((t) => (
                              <TableRow key={t.id}>
                                <TableCell>{format(parseISO(t.created_at), "HH:mm")}</TableCell>
                                <TableCell>
                                  <Badge variant={t.tipo === "receita" ? "default" : "destructive"}>
                                    {t.tipo === "receita" ? "Entrada" : "Saída"}
                                  </Badge>
                                </TableCell>
                                <TableCell>{t.descricao || "-"}</TableCell>
                                <TableCell>{t.metodo_pagamento || "-"}</TableCell>
                                <TableCell className={`text-right font-medium ${t.tipo === "receita" ? "text-green-600" : "text-red-600"}`}>
                                  R$ {parseFloat(t.valor.toString()).toFixed(2)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}

                      {(!caixa.transacoes || caixa.transacoes.length === 0) && (
                        <p className="text-center text-muted-foreground py-4">
                          Nenhuma movimentação registrada neste dia
                        </p>
                      )}
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        </>
      )}

      {caixas.length === 0 && !loading && (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Selecione o período e clique em "Gerar Relatório"</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default RelatorioFechamentoCaixa;
