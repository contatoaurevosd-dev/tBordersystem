-- Remover política antiga
DROP POLICY IF EXISTS "Users with entregas permission can view entregas" ON public.garantias;

-- Criar política para atendentes verem apenas entregas das suas próprias O.S
CREATE POLICY "Users with entregas permission can view own entregas"
ON public.garantias
FOR SELECT
USING (
  has_permission(auth.uid(), 'entregas'::text, 'read'::text) 
  AND status IN ('aguardando', 'entregue')
  AND EXISTS (
    SELECT 1 FROM public.ordens_servico os
    WHERE os.id = garantias.ordem_servico_id
    AND os.created_by = auth.uid()
  )
);