-- Remover política antiga de update
DROP POLICY IF EXISTS "Users with entregas permission can update entregas" ON public.garantias;

-- Criar política para atendentes atualizarem apenas entregas das suas próprias O.S
CREATE POLICY "Users with entregas permission can update own entregas"
ON public.garantias
FOR UPDATE
USING (
  has_permission(auth.uid(), 'entregas'::text, 'update'::text) 
  AND status IN ('aguardando', 'entregue')
  AND EXISTS (
    SELECT 1 FROM public.ordens_servico os
    WHERE os.id = garantias.ordem_servico_id
    AND os.created_by = auth.uid()
  )
);