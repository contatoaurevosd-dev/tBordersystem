-- Attach the auto_create_receita_garantia trigger to garantias table
CREATE TRIGGER trigger_auto_create_receita_garantia
BEFORE UPDATE ON public.garantias
FOR EACH ROW
EXECUTE FUNCTION public.auto_create_receita_garantia();