-- Criar política para permitir que usuários com permissão de entregas vejam garantias aguardando/entregue
CREATE POLICY "Users with entregas permission can view entregas"
ON public.garantias
FOR SELECT
USING (
  has_permission(auth.uid(), 'entregas'::text, 'read'::text) 
  AND status IN ('aguardando', 'entregue')
);

-- Criar política para permitir que usuários com permissão de entregas atualizem garantias (concluir entrega)
CREATE POLICY "Users with entregas permission can update entregas"
ON public.garantias
FOR UPDATE
USING (
  has_permission(auth.uid(), 'entregas'::text, 'update'::text) 
  AND status IN ('aguardando', 'entregue')
);