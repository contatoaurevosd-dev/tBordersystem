-- Habilitar realtime para audit_logs
ALTER PUBLICATION supabase_realtime ADD TABLE public.audit_logs;