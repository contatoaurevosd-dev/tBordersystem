import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error('Missing authorization header');
      return new Response(
        JSON.stringify({ error: 'Não autorizado' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create Supabase client and verify user
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      console.error('Auth error:', authError?.message || 'No user found');
      return new Response(
        JSON.stringify({ error: 'Não autorizado' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Network print request from user: ${user.id}`);

    const { ip, port, data } = await req.json();

    if (!ip || !port || !data) {
      return new Response(
        JSON.stringify({ error: 'IP, porta e dados são obrigatórios' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate IP is in private network ranges (printers should be on local network)
    const ipParts = ip.split('.').map(Number);
    const isPrivateIP = 
      (ipParts[0] === 10) || // 10.x.x.x
      (ipParts[0] === 172 && ipParts[1] >= 16 && ipParts[1] <= 31) || // 172.16.x.x - 172.31.x.x
      (ipParts[0] === 192 && ipParts[1] === 168); // 192.168.x.x

    if (!isPrivateIP) {
      console.error(`Blocked attempt to connect to non-private IP: ${ip}`);
      return new Response(
        JSON.stringify({ error: 'Apenas IPs de rede privada são permitidos' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate port is a common printer port
    const validPorts = [9100, 515, 631];
    const portNum = parseInt(port);
    if (!validPorts.includes(portNum)) {
      console.error(`Blocked attempt to connect to non-printer port: ${port}`);
      return new Response(
        JSON.stringify({ error: 'Apenas portas de impressora são permitidas (9100, 515, 631)' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Conectando à impressora em ${ip}:${port}`);

    // Convert base64 back to bytes
    const binaryString = atob(data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // Connect to printer via TCP with timeout
    const connectPromise = Deno.connect({
      hostname: ip,
      port: portNum,
      transport: "tcp",
    });

    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Connection timeout')), 10000);
    });

    const conn = await Promise.race([connectPromise, timeoutPromise]) as Deno.TcpConn;

    console.log('Conexão estabelecida, enviando dados...');

    // Send ESC/POS data
    await conn.write(bytes);
    
    console.log(`Dados enviados com sucesso por usuário ${user.id}`);

    // Close connection
    conn.close();

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Impressão enviada com sucesso',
        bytesSent: bytes.length 
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Erro na impressão de rede:', error);
    
    return new Response(
      JSON.stringify({ 
        error: 'Falha ao conectar com a impressora',
        details: error instanceof Error ? error.message : String(error)
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
