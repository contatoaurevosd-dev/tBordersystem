-- Enable realtime for print_jobs table
ALTER PUBLICATION supabase_realtime ADD TABLE public.print_jobs;